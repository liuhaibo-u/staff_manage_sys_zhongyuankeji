#include <stdio.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <sqlite3.h>
#include <unistd.h>

#define PORT 5002
#define IP 	 "192.168.1.137"
#define N 1024

#define A 1
#define B 2
#define T 3
#define D 4
#define C 5
#define F 6

struct MSG
{
	int id;         //工号
	char name[N];   //姓名
	int age;        //年龄
	char addr[N];   //家庭地址
	char work[10];  //职位
	int  salary;    //工资
    int  utype;     //权限
};

struct account
{
	int type;       //类型
	char account[N]; //账户
	char password[N]; //密码
	char text[N];     //消息
	struct MSG info;          //员工信息结构体
}account;

void do_admin_mode(int sockfd, struct account account);
void do_user_mode(int sockfd, struct account account);
void do_quit(int sockfd);
void do_add_user(int sockfd, struct account account);
void do_delete_user(int sockfd, struct account account);
void do_change_info(int sockfd , struct account account);
void do_find_info(int sockfd ,struct account account);
void user_find(int sockfd, struct account account);

int main(int argc, const char *argv[])
{
	int sockfd, listenfd;
	struct sockaddr_in serveraddr,clientaddr;
	char buf[N] = {0};
	socklen_t addrlen = sizeof(serveraddr);
	socklen_t cli_len = sizeof(clientaddr);
	ssize_t recvbyte , sendbyte;

	//创建套接字
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1){
		perror("socket error.\n");
		return -1;
	}
	printf("sockfd create success. sockfd is %d\n",sockfd);

	//填充
	memset(&serveraddr,0,sizeof(serveraddr));
	memset(&clientaddr,0,sizeof(clientaddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port   = htons(PORT);
	serveraddr.sin_addr.s_addr = inet_addr(IP);


	//请求链接
	if((connect(sockfd, (const struct sockaddr *)&serveraddr, addrlen)) == -1){
		perror("connect error.\n");
		return -1;
	}
	printf("服务器连接成功!\n");

	while(1){
		int key;
		printf("**************************************************************\n");
		printf("*********  欢 迎 使 用 忠 原 科 技 员 工 管 理 系 统  ********\n");
        printf("**************************************************************\n");
		printf("***************  请 根 据 提 示 输 入  ***********************\n");
        printf("**************************************************************\n");
		printf("***************  1. 管 理 员 模 式     ***********************\n");
		printf("***************  2. 普 通 用 户 模 式  ***********************\n");
		printf("***************  3. 退       出        ***********************\n");
		printf("**************************************************************\n");

		printf("请输入>>>>");
		scanf("%d",&key);
		getchar();

		switch(key){
		case 1: do_admin_mode(sockfd,account);break;
		case 2: do_user_mode(sockfd,account);break;
		case 3: do_quit(sockfd);goto end;
		default:printf("参数错误,请重新输入.\n");break;
		}

	}
end:
	close(sockfd);

	return 0;
}

void do_admin_mode(int sockfd, struct account account)
{
	memset(&account, 0, sizeof(account));
	account.type = A;
	printf("请输入管理员账号>>>>");
	scanf("%s",account.account);
	getchar();

	printf("请输入密码>>>>");
	scanf("%s",account.password);
	getchar();

	send(sockfd,&account,sizeof(account),0);
	memset(&account,0,sizeof(account));
	recv(sockfd,&account,sizeof(account),0);
	printf("%s\n",account.text);

	if(strncmp(account.text,"ok", 2) == 0){
table:
		printf("**************************************************************\n");
		printf("*********  欢 迎 使 用 忠 原 科 技 员 工 管 理 系 统  ********\n");
        printf("**************************************************************\n");
		printf("***************  请 根 据 提 示 输 入  ***********************\n");
        printf("**************************************************************\n");
		printf("***************  1. 添 加 用 户        ***********************\n");
		printf("***************  2. 删 除 用 户        ***********************\n");
		printf("***************  3. 修 改 信 息        ***********************\n");
        printf("***************  4. 查 询 信 息        ***********************\n");
        printf("***************  5. 返 回 上 一 级     ***********************\n");
		printf("**************************************************************\n");

		int key = 0;
		printf("请输入>>>");
		scanf("%d",&key);
		getchar();
		switch(key){
		case 1: do_add_user(sockfd,account);goto table;
		case 2: do_delete_user(sockfd,account);goto table;
		case 3: do_change_info(sockfd,account);goto table;
		case 4: do_find_info(sockfd,account);goto table;
		case 5: break;
		default:printf("参数错误,请重新输入.\n");goto table;
		}

	}

}

void do_user_mode(int sockfd, struct account account)
{
		memset(&account,0,sizeof(account));
		account.type = B;
		printf("请输入用户名>>>");
		scanf("%s",account.account);
		getchar();

		printf("请输入密码>>>");
		scanf("%s",account.password);
		getchar();

		send(sockfd,&account,sizeof(account),0);
		memset(&account,0,sizeof(account));
		recv(sockfd,&account,sizeof(account),0);
		printf("%s\n",account.text);

		if(strncmp(account.text,"ok", 2) == 0){
            printf("**************************************************************\n");
            printf("*********  欢 迎 使 用 忠 原 科 技 员 工 管 理 系 统  ********\n");
            printf("**************************************************************\n");
            printf("***************  请 根 据 提 示 输 入  ***********************\n");
            printf("**************************************************************\n");
            printf("***************  1. 修 改 信 息        ***********************\n");
            printf("***************  2. 查 询 信 息        ***********************\n");
            printf("***************  3. 返 回 上 一 级     ***********************\n");
            printf("**************************************************************\n");


			int key = 0;
			printf("请输入>>>");
			scanf("%d",&key);
			getchar();
			switch(key){
                case 1:do_change_info(sockfd,account);break;
                case 2:user_find(sockfd,account);break;
                case 3:break;
                default:printf("参数错误,请重新输入.\n");break;
			}

		}    


}

void do_quit(int sockfd)
{
	printf("退出成功，欢迎下次使用.\n");
	close(sockfd);
	return;
}

void do_add_user(int sockfd, struct account account)
{
	memset(&account,0,sizeof(account));
	account.type = T;
	printf("请输入你要添加用户的账号：");
	scanf("%s",account.account);
	getchar();

	printf("请输入新账户密码:");
	scanf("%s",account.password);    
	getchar();

    printf("请输入权限类型(1：管理员，0：普通用户):");
	scanf("%d",&account.info.utype);    
	getchar();  

	printf("请输入员工ID：");
	scanf("%d",&account.info.id);    
	getchar();

	printf("请输入员工姓名：");
	scanf("%s",account.info.name);    
	getchar();

	printf("请输入员工年龄：");
	scanf("%d",&account.info.age);    
	getchar();

	printf("请输入员工家庭地址：");
	scanf("%s",account.info.addr);    
	getchar();

	printf("请输入员工职位：");
	scanf("%s",account.info.work);    
	getchar();

	printf("请输入员工工资：");
	scanf("%d",&account.info.salary);    
	getchar();

	send(sockfd,&account,sizeof(account),0);
	memset(&account,0,sizeof(account));
	recv(sockfd,&account,sizeof(account),0);
	printf("%s\n",account.text);

}

void do_delete_user(int sockfd, struct account account)
{
	memset(&account,0,sizeof(account));
	account.type = D;
	printf("请输入你要删除员工的ID：");
	scanf("%d",&account.info.id);
	getchar();

	send(sockfd,&account,sizeof(account),0);
	memset(&account,0,sizeof(account));
	recv(sockfd,&account,sizeof(account),0);
	printf("%s\n",account.text);  
}

void do_change_info(int sockfd , struct account account)
{  
	int key  = 0;
	memset(&account,0,sizeof(account));
	account.type = C;
	printf("请输入你要修改信息员工的ID：");
	scanf("%d",&account.info.id);
	getchar();
table1:
	printf("*****************************************************\n");
	printf("**********1.年龄  2.工资   3. 职位   4姓名***********\n");
	printf("*****************************************************\n");

	printf("请输入你要修改的信息标号：");
	scanf("%d",&key);
	getchar();

	switch(key){
	case 1: printf("请输入信的年龄:"); scanf("%d",&account.info.age); getchar();break;
	case 2: printf("请输入新的工资:"); scanf("%d",&account.info.salary);getchar();break;
	case 3: printf("请输入您新的职位:");scanf("%s",account.info.work);getchar();break;
	case 4: printf("请输入您的姓名：");scanf("%s",account.info.name);getchar();break;
	default:printf("您输入的参数非法,请重新输入.\n");goto table1;
	}

	send(sockfd,&account,sizeof(account),0);
	send(sockfd,&key,sizeof(key),0);
	memset(&account,0,sizeof(account));
	recv(sockfd,&account,sizeof(account),0);
	printf("%s\n",account.text);  

}


void do_find_info(int sockfd ,struct account account)
{
	int key;
	memset(&account,0,sizeof(account));
	account.type = F;

table2:
	printf("****************************************************************\n");
	printf("*************0.查询全部  1.ID  2.名字   3. 职位   **************\n");
	printf("****************************************************************\n");

	printf("请输入索引编号:");
	scanf("%d",&key);
	getchar();

	switch(key){
	case 0: break;
	case 1: printf("请输入你要查找员工的ID："); scanf("%d",&account.info.id); getchar();break;
	case 2: printf("请输入你要查找员工的姓名："); scanf("%s",account.info.name);getchar();break;
	case 3: printf("请输入你要查找的职位:");scanf("%s",account.info.work);getchar();break;
	default:printf("您输入的参数非法,请重新输入.\n");goto table2;
	}    

	send(sockfd,&account,sizeof(account),0);
	send(sockfd,&key,sizeof(key),0);
	//接受信息并打印
	while(1){
		memset(account.text,0,sizeof(account.text));
		recv(sockfd,&account,sizeof(account),0);
		if(strncmp(account.text,"ok",2) == 0)
		{
			break;
		}

		printf("%s",account.text); 
	}

}

void user_find(int sockfd, struct account account)
{
    int key = 1;
   	memset(&account,0,sizeof(account));
	account.type = F; 

    printf("请输入您的ID："); 
    scanf("%d",&account.info.id);
    getchar();

    send(sockfd,&account,sizeof(account),0);
    send(sockfd,&key,sizeof(key),0);

	while(1){
		memset(account.text,0,sizeof(account.text));
		recv(sockfd,&account,sizeof(account),0);
		if(strncmp(account.text,"ok",2) == 0)
		{
			break;
		}

		printf("%s",account.text); 
	}

    
}
