#include <stdio.h>
#include <sys/types.h>          /* See NOTES */
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <sqlite3.h>
#include <unistd.h>

#define PORT 5002
#define IP 	 "192.168.1.137"
#define N 1024
#define DATABASE "data.db"

#define A 1
#define B 2
#define T 3
#define D 4
#define C 5
#define F 6

sqlite3* db;
char sql[N] = {0};
char * errmsg;

struct MSG
{
	int id;         //工号
	char name[N];   //姓名
	int age;        //年龄
	char addr[N];   //家庭地址
	char work[10];  //职位
	int  salary;    //工资
	int  utype;     //权限
};

struct account
{
	int type;       //类型
	char account[N]; //账户
	char password[N]; //密码
	char text[N];     //消息
	struct MSG info;          //员工信息结构体
}account;

void process_admin_modu(int listenfd,struct account account);
void process_user_modu(int listenfd,struct account account);
void process_add_user(int listenfd,struct account account);
void process_delete_user(int listenfd, struct account account);
void process_change_user(int listenfd,struct account account);
void process_find_user(int listenfd,struct account account);





int main(int argc, const char *argv[])
{
	int sockfd, listenfd;
	struct sockaddr_in serveraddr,clientaddr;
	char buf[N] = {0};
	socklen_t addrlen = sizeof(serveraddr);
	socklen_t cli_len = sizeof(clientaddr);
	ssize_t recvbyte , sendbyte;

	//创建数据库
	if(sqlite3_open(DATABASE,&db) != SQLITE_OK){
		printf("errmsg is %s",sqlite3_errmsg(db));
	}else{
		printf("数据库创建并打开成功。\n");
	}

	//创建一张信息表
	sprintf(sql,"create table userinfo(account text, password text, utype int, id int, name text, age int, addr text, work text, salary int);");
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK){
		printf("errmsg is %s\n",errmsg);
	}else{
		printf("员工信息表创建成功.\n");
        //注册一个管理员
	memset(&sql,0,sizeof(sql));
	sprintf(sql,"insert into userinfo values('admin','admin',1 ,0000,'管理员',0,'服务器','管理员',9999);");
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK){
		printf("errmsg is %s\n",errmsg);
	}else{
		printf("管理员注册成功.\n");
	}
	}

	


	//创建套接字
	sockfd = socket(AF_INET, SOCK_STREAM, 0);
	if(sockfd == -1){
		perror("socket error.\n");
		return -1;
	}
	printf("sockfd create success. sockfd is %d\n",sockfd);

	//填充
	memset(&serveraddr,0,sizeof(serveraddr));
	memset(&clientaddr,0,sizeof(clientaddr));
	serveraddr.sin_family = AF_INET;
	serveraddr.sin_port   = htons(PORT);
	serveraddr.sin_addr.s_addr = inet_addr(IP);

	//绑定
	if((bind(sockfd, (const struct sockaddr *)&serveraddr,addrlen)) == -1){
		perror("绑定失败.\n");
		return -1;
	}

	//监听
	if((listen(sockfd, 10)) == -1){
		perror("listen error.\n");
		return -1;
	}
	printf("监听中.....\n");

	//等待链接
	while(1){

		listenfd = accept(sockfd, (struct sockaddr *)&clientaddr, &cli_len);
		if(listenfd == -1){
			perror("accept error.\n");
			return -1;
		}
		printf("连接成功.\n");
		while(1){
			memset(&account,0,sizeof(account));
			recv(listenfd,&account,sizeof(account),0);
			switch(account.type)
			{
			case A:process_admin_modu(listenfd,account);break;
			case B:process_user_modu(listenfd,account);break;
			case T:process_add_user(listenfd,account);break;
			case D:process_delete_user(listenfd,account);break;
			case C:process_change_user(listenfd,account);break;
			case F:process_find_user(listenfd,account);break;
			}
		}


	}
	close(sockfd);

	return 0;
}

void process_admin_modu(int listenfd,struct account account)
{
	printf("管理员模式\n");

	char **rep;
	int n_row;
	int n_column;
	int i,j;
    
	memset(&sql,0,sizeof(sql));
	sprintf(sql,"select * from userinfo where account = '%s' and password = '%s' and utype = 1;",account.account,account.password);

    if(sqlite3_get_table(db,sql,&rep,&n_row,&n_column,&errmsg)!=SQLITE_OK){
            printf("errmsg is %s\n",errmsg);
        }else{
            if(n_row == 0){
                strcpy(account.text,"账户或密码错误,或者不是管理员.");
                send(listenfd,&account,sizeof(account),0);
            }else{
                strcpy(account.text,"ok");
                send(listenfd,&account,sizeof(account),0);
            } 
        }  
}

void process_user_modu(int listenfd,struct account account)
{
	printf("普通用户模式\n");

	char **rep;
	int n_row;
	int n_column;
	int i,j;

	memset(&sql,0,sizeof(sql));
	sprintf(sql,"select * from userinfo where account = '%s' and password = '%s' and utype = 0;",account.account,account.password);
	if(sqlite3_get_table(db,sql,&rep,&n_row,&n_column,&errmsg)!=SQLITE_OK){
		printf("errmsg is %s\n",errmsg);
	}else{
		if(n_row == 0){
			strcpy(account.text,"用户不存在,请联系管理员添加后再查询");
			send(listenfd,&account,sizeof(account),0);
		}else{
			strcpy(account.text,"ok");
			send(listenfd,&account,sizeof(account),0);
		}

	}
}

void process_add_user(int listenfd,struct account account)
{
	printf("添加用户\n");

	memset(&sql,0,sizeof(sql));
	sprintf(sql,"insert into userinfo values('%s','%s',%d,%d,'%s',%d,'%s','%s','%d');",account.account,account.password,account.info.utype,account.info.id,account.info.name,
			account.info.age,account.info.addr,account.info.work,account.info.salary);
	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK){
		printf("errmsg is : %s\n",errmsg);

		memset(&account, 0,sizeof(account));
		strcpy(account.text,"添加用户失败.");
		send(listenfd,&account,sizeof(account),0);
		return;
	}else{
		memset(&account, 0,sizeof(account));
		strcpy(account.text,"添加用户成功.");
		send(listenfd,&account,sizeof(account),0);
		return;
	}
}

void process_delete_user(int listenfd, struct account account)
{
	printf("删除用户\n");

	memset(&sql,0,sizeof(sql));
	sprintf(sql,"delete from userinfo where id = %d;",account.info.id);

	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK){
		printf("errmsg is : %s\n",errmsg);  
		memset(&account, 0,sizeof(account));
		strcpy(account.text,"删除用户失败.");
		send(listenfd,&account,sizeof(account),0);
		return;
	}else{
		memset(&account, 0,sizeof(account));
		strcpy(account.text,"删除用户成功.");
		send(listenfd,&account,sizeof(account),0);
		return;
	}
}

void process_change_user(int listenfd,struct account account)
{
	printf("更改用户信息\n");

	int key = 0;
	recv(listenfd,&key,sizeof(key),0);
	memset(&sql,0,sizeof(sql));

	switch(key){
	case 1:sprintf(sql,"update userinfo set age = %d where id = %d ",account.info.age,account.info.id);break;
	case 2:sprintf(sql,"update userinfo set salary = '%d' where id = %d ",account.info.salary,account.info.id);break;
	case 3:sprintf(sql,"update userinfo set work = '%s' where id = %d ",account.info.work,account.info.id);break;
	case 4:sprintf(sql,"update userinfo set name = '%s' where id = %d ",account.info.name,account.info.id);break;
	}

	if(sqlite3_exec(db,sql,NULL,NULL,&errmsg) != SQLITE_OK){
		printf("errmsg is : %s\n",errmsg);  
		memset(&account, 0,sizeof(account));
		strcpy(account.text,"更新用户信息失败.");
		send(listenfd,&account,sizeof(account),0);
		return;
	}else{
		memset(&account, 0,sizeof(account));
		strcpy(account.text,"更新用户信息成功.");
		send(listenfd,&account,sizeof(account),0);
		return;
	}


}

void process_find_user(int listenfd,struct account account)
{
	printf("查找用户\n");

	int key = 0;
	int i = 0,j = 0;
	char **resultp;
	int nrow,ncolumn;
	char *errmsg;

	recv(listenfd,&key,sizeof(key),0);
	memset(&sql,0,sizeof(sql));

	switch(key){
	case 0:sprintf(sql,"select * from userinfo");break;
	case 1:sprintf(sql,"select * from userinfo where id = %d",account.info.id);break;
	case 2:sprintf(sql,"select * from userinfo where name = '%s'",account.info.name);break;
	case 3:sprintf(sql,"select * from userinfo where work = '%s'",account.info.work);break;
	}

	if(sqlite3_get_table(db, sql, &resultp,&nrow,&ncolumn,&errmsg) != SQLITE_OK){
		printf("%s.\n",errmsg);
	}else{
		printf("searching.....\n");
		for(i = 0; i < ncolumn; i ++){
			sprintf(account.text,"%-10s",resultp[i]);
			send(listenfd,&account,sizeof(account),0);
		}
		strcpy(account.text,"\n");
		send(listenfd,&account,sizeof(account),0);
		int index = ncolumn;
		for(i = 0; i < nrow; i ++){
			for(j = 0 ; j < ncolumn; j ++){
				sprintf(account.text,"%-10s",resultp[index++]);
				send(listenfd,&account,sizeof(account),0);  
			}
			strcpy(account.text,"\n");
			send(listenfd,&account,sizeof(account),0);
		}
		strcpy(account.text,"ok");
		send(listenfd,&account,sizeof(account),0);
	}
}
